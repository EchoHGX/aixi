;(function(win,$){
	
	var defaultPars = {
		el: '',
	}

	var turntable = function(options){
		this.options = {
			
		}
	} 
}(window,$))